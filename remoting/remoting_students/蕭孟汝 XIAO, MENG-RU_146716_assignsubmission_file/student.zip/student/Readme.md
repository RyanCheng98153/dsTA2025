1. B
2. A
3. 第 4 ⾏
4. string 代表型別，後面的數字用來當識別碼代表次序。
5. 會回傳"查詢信件狀態(尾號 xxx) 找不到該信件"，Client 端不會取得 response。
6. "咆嘯信已送達"
7. 會被轉成 camelCase