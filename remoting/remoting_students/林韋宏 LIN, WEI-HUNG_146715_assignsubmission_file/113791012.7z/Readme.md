1. B
2. A
3. 皆在第四行被Load進去
4. string 代表request/response message的內容變數型態，其後面等號接的數字代表資料的排序號
5. track: 查詢信件狀態(尾號 XXX) 找不到該信件 / server: 查詢信件狀態 (尾碼 XXX): 信件不存在
6. 咆嘯信已送達
7. 我將track中的TrackRequest中的pickupCode改成pickup_Code後，仍可以正常運作，並無發現異常，但查過資料後發現，若使用底線分隔，有可能會讓變數名稱decode後出現跟其他變數/函式撞名的情況