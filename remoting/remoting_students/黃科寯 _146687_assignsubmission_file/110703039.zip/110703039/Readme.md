1. B
2. A
3. 第4行。const owlPostProto = grpc.loadPackageDefinition(packageDefinition).owlpost;
4. string 代表一個用於儲存文字的字串資料類型；等號後面的數字是欄位的唯一標籤號碼，用於二進制編碼和支援架構演進。 
5. "查詢信件狀態(尾號 XXX) 找不到該信件" 
6. "查詢信件狀態(尾號 XX4)：咆嘯信已送達"
7. 語法上允許，但違反了 Google Protobuf Style Guide 的建議。程式碼生成可能不一致或不符合目標語言慣例
