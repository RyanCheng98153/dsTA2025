# 
1. B
2. A
3. const owlPostProto = grpc.loadPackageDefinition(packageDefinition).owlpost;
4. string 代表字串的型別，數字則是將每個欄位編號
5. 查詢信件狀態(尾號 XXX) 找不到該信件
callback(err) 傳回的是錯誤物件而非回傳 null、undefined
6. 咆嘯信已送達
7. 可以的，一樣可以執行，但在某些語法中會被轉換型態成駝峰式語法