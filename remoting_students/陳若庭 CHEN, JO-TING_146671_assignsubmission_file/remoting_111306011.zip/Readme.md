1. B
2. A
3. 第4⾏
4. string 代表型別，數字代表序號，用來序列化
5. 找不到該信件，client 的 response 變成 undefined，需處理err
6. 咆嘯信已送達
7. proto-loader 預設會把底線轉換成 camelCase 導致程式因為參數名稱改變而出錯