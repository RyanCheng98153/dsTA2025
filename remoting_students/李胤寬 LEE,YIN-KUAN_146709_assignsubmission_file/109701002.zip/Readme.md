1. B
2. A
3. 第4行
4. string 代表字串，等號後面接數字表示序號
5. 會回傳 "查詢信件狀態(尾號 ***) 找不到該信件"
6. "咆嘯信已送達"
7. 如果改studentName改成student_Name，會變成 "學生: undefined"