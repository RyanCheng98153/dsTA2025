1.B
2.A
3.對應到，const owlPostProto = grpc.loadPackageDefinition(packageDefinition).owlpost;
4.string表示這些變數的資料型別，後面的數字是 Protocol Buffers 用來序列化資料的重要索引
5.在track端會顯示，查詢信件狀態(尾號 111) 找不到該信件
  在server端會顯示，查詢信件狀態 (尾碼 111): 信件不存在
6.會顯示，查詢信件狀態(尾號 994)：咆嘯信已送達
          學生: Harry Potter
          學院: 格蘭芬多
7.沒反應，因為使用底線命名屬於合法行為