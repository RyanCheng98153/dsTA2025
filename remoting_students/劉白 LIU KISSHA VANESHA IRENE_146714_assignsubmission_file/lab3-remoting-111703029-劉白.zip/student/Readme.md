1. B
2. A
3. 第4⾏ - const owlPostProto = grpc.loadPackageDefinition(packageDefinition).owlpost;
4. string 代表字串，等號後面的數字是欄位標籤
5. 查詢信件狀態(尾號 undefined) 找不到該信件
6. "咆嘯信已送達"
7. 不會發生什麽是