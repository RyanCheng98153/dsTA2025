1. B
2. A 
3. 第四行 
4. string代表一種資料類別(data type)，數字代表了欄位編號(field number)，在protocol buffer我們用它當作序列化(binary serialization)時對應欄位。
5. 會回傳: 查詢信件狀態 (尾碼 XXX): 信件不存在
6. "咆嘯信已送達"
7. 使用底線(underscore)命名不會有任何變化