1.B
2.A
3.grpc.loadPackageDefinition(packageDefinition)
4.proto 中 string 使用 UTF-8
5.查詢信件狀態(尾號 xxx) 找不到該信件
6.查詢信件狀態(尾號 4) 找不到該信件
7.只要_不在變數名字的最前面基本上都行