1. B
2. A
3. 第4行
4. string 是 protobuf type. 等號後面的數字是field number，在message被序列化時，用來在產生的binary data中區分各個field。
5. track.js: "查詢信件狀態(尾號 124) 找不到該信件"
    server.js: "查詢信件狀態 (尾碼 124): 信件不存在"
6. "查詢信件狀態(尾號 124) 找不到該信件"
7. undefined
