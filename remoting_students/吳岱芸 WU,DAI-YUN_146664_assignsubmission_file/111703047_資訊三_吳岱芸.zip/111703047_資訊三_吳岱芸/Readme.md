1. B 
2. A
3. 第4行，const owlPostProto = grpc.loadPackageDefinition(packageDefinition).owlpost;
4. string 代表字串類型，後面的數字代表該欄位的編號
5. server會回傳"信件不存在"；client會回傳"找不到該信件"
6. "咆嘯信已送達"
7. 是合法的，但會影響轉換後名稱，無法變大寫
